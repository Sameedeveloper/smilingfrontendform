import React, { useState, useEffect } from 'react'
import { Grid } from '@material-ui/core'
import Controls from '../../components/controls/Controls'
import { useForm, Form } from '../../components/useForm'
import * as employeeService from '../../services/employeeService'

const genderItems = [
  { id: 'male', title: 'Male' },
  { id: 'female', title: 'Female' },
  { id: 'other', title: 'Other' },
]

const initialFValues = {
  id: 0,
  firstName: '',
  secondName: '',
  email: '',

  gender: 'male',
  professionId: '',
  ShoeSizeId: '',
  HairColorId: '',
  HairLengthId: '',
  BraSizeId: '',
  WaistSizeId: '',
  HeightId: '',
  WeightId: '',
  CastingTypeId: '',
  birthDate: new Date(),
}

export default function EmployeeForm() {
  const validate = (fieldValues = values) => {
    let temp = { ...errors }

    if ('email' in fieldValues)
      temp.email = /$^|.+@.+..+/.test(fieldValues.email)
        ? ''
        : 'Email is not valid.'

    if ('professionId' in fieldValues)
      temp.professionId =
        fieldValues.professionId.length != 0 ? '' : 'This field is required.'
    setErrors({
      ...temp,
    })

    if (fieldValues == values) return Object.values(temp).every((x) => x == '')
  }

  const { values, setValues, errors, setErrors, handleInputChange, resetForm } =
    useForm(initialFValues, true, validate)

  const handleSubmit = (e) => {
    e.preventDefault()
    employeeService.insertEmployee(values)
    resetForm()
  }

  return (
    <Form onSubmit={handleSubmit}>
      <Grid container>
        <Grid item xs={6}>
          <Controls.Input
            name='firstName'
            label='First Name'
            value={values.firstName}
            onChange={handleInputChange}
            error={errors.firstName}
          />
          <Controls.Input
            name='secondName'
            label='Second Name'
            value={values.secondName}
            onChange={handleInputChange}
            error={errors.secondName}
          />
          <Controls.Input
            label='Email'
            name='email'
            value={values.email}
            onChange={handleInputChange}
            error={errors.email}
          />

          <Controls.Select
            name='HairLengthId'
            label='Hair Length'
            value={values.HairLengthId}
            onChange={handleInputChange}
            options={employeeService.getHairLengthCollection()}
            error={errors.HairLengthId}
          />

          <Controls.Select
            name='BraSizeId'
            label='Bra Size'
            value={values.BraSizeId}
            onChange={handleInputChange}
            options={employeeService.getBraSizeCollection()}
            error={errors.BraSizeId}
          />
          <Controls.Select
            name='WaistSizeId'
            label='Waist Size'
            value={values.WaistSizeId}
            onChange={handleInputChange}
            options={employeeService.getWaistSizeCollection()}
            error={errors.WaistSizeId}
          />

          <Controls.Select
            name='HeightId'
            label='Height'
            value={values.HeightId}
            onChange={handleInputChange}
            options={employeeService.getHeightCollection()}
            error={errors.HeightId}
          />
        </Grid>
        <Grid item xs={6}>
          <Controls.Select
            name='WeightId'
            label='Weight'
            value={values.WeightId}
            onChange={handleInputChange}
            options={employeeService.getWeightCollection()}
            error={errors.WeightId}
          />
          <Controls.Select
            name='CastingTypeId'
            label='Casting Type'
            value={values.CastingTypeId}
            onChange={handleInputChange}
            options={employeeService.getCastingTypeCollection()}
            error={errors.CastingTypeId}
          />
          <Controls.RadioGroup
            name='gender'
            label='Gender'
            value={values.gender}
            onChange={handleInputChange}
            items={genderItems}
          />
          <Controls.Select
            name='professionId'
            label='Profession'
            value={values.professionId}
            onChange={handleInputChange}
            options={employeeService.getProfessionCollection()}
            error={errors.professionId}
          />
          <Controls.Select
            name='ShoeSizeId'
            label='Shoe Size'
            value={values.ShoeSizeId}
            onChange={handleInputChange}
            options={employeeService.getShoeSizeCollection()}
            error={errors.ShoeSizeId}
          />
          <Controls.Select
            name='HairColorId'
            label='Hair Color'
            value={values.HairColorId}
            onChange={handleInputChange}
            options={employeeService.getHairColorCollection()}
            error={errors.HairColorId}
          />
          <Controls.DatePicker
            name='birthDate'
            label='Birth Date'
            value={values.birthDate}
            onChange={handleInputChange}
          />

          <div>
            <Controls.Button type='submit' text='Submit' />
            <Controls.Button text='Reset' color='default' onClick={resetForm} />
          </div>
        </Grid>
      </Grid>
    </Form>
  )
}

import axios from 'axios'
import { useState } from 'react'

const KEYS = {
  employees: 'employees',
  employeeId: 'employeeId',
}

export const getProfessionCollection = () => [
  { id: '1', title: 'Comedian' },
  { id: '2', title: 'Actor' },
  { id: '3', title: 'Actress' },
  { id: '4', title: 'Model' },
]

export const getShoeSizeCollection = () => [
  { id: '1', title: 'EU 35' },
  { id: '2', title: 'EU 36' },
  { id: '3', title: 'EU 37' },
  { id: '4', title: 'EU 38' },
  { id: '5', title: 'EU 39' },
  { id: '6', title: 'EU 40' },
]

export const getHairColorCollection = () => [
  { id: '1', title: 'Black' },
  { id: '2', title: 'Brown' },
  { id: '3', title: 'Blonde' },
]

export const getHairLengthCollection = () => [
  { id: '1', title: '10 inch' },
  { id: '2', title: '12 inch' },
  { id: '3', title: '14 inch' },
  { id: '4', title: '16 inch' },
  { id: '5', title: '18 inch' },
  { id: '6', title: '20 inch' },
]

export const getBraSizeCollection = () => [
  { id: '1', title: 'XS' },
  { id: '2', title: 'S' },
  { id: '3', title: 'M' },
  { id: '4', title: 'L' },
  { id: '5', title: 'XL' },
  { id: '6', title: 'XXL' },
]

export const getWaistSizeCollection = () => [
  { id: '1', title: '64cm' },
  { id: '2', title: '69cm' },
  { id: '3', title: '74cm' },
  { id: '4', title: '79cm' },
  { id: '5', title: '84cm' },
  { id: '6', title: '89cm' },
]

export const getHeightCollection = () => [
  { id: '1', title: '160cm' },
  { id: '2', title: '164cm' },
  { id: '3', title: '168cm' },
  { id: '4', title: '172cm' },
  { id: '5', title: '176cm' },
  { id: '6', title: '180cm' },
]

export const getWeightCollection = () => [
  { id: '1', title: '50kg' },
  { id: '2', title: '54kg' },
  { id: '3', title: '58kg' },
  { id: '4', title: '62kg' },
  { id: '5', title: '66kg' },
  { id: '6', title: '70kg' },
]

export const getCastingTypeCollection = () => [
  { id: '1', title: 'Movies' },
  { id: '2', title: 'Television' },
  { id: '3', title: 'Commercial' },
  { id: '4', title: 'Newspaper' },
  { id: '5', title: 'Magazine' },
]

export const ProfessionCollection = [
  { id: '1', title: 'Comedian' },
  { id: '2', title: 'Actor' },
  { id: '3', title: 'Actress' },
  { id: '4', title: 'Model' },
]

export const ShoeSizeCollection = [
  { id: '1', title: 'EU 35' },
  { id: '2', title: 'EU 36' },
  { id: '3', title: 'EU 37' },
  { id: '4', title: 'EU 38' },
  { id: '5', title: 'EU 39' },
  { id: '6', title: 'EU 40' },
]

export const HairColorCollection = [
  { id: '1', title: 'Black' },
  { id: '2', title: 'Brown' },
  { id: '3', title: 'Blonde' },
]

export const HairLengthCollection = [
  { id: '1', title: '10 inch' },
  { id: '2', title: '12 inch' },
  { id: '3', title: '14 inch' },
  { id: '4', title: '16 inch' },
  { id: '5', title: '18 inch' },
  { id: '6', title: '20 inch' },
]

export const BraSizeCollection = [
  { id: '1', title: 'XS' },
  { id: '2', title: 'S' },
  { id: '3', title: 'M' },
  { id: '4', title: 'L' },
  { id: '5', title: 'XL' },
  { id: '6', title: 'XXL' },
]

export const WaistSizeCollection = [
  { id: '1', title: '64cm' },
  { id: '2', title: '69cm' },
  { id: '3', title: '74cm' },
  { id: '4', title: '79cm' },
  { id: '5', title: '84cm' },
  { id: '6', title: '89cm' },
]

export const HeightCollection = [
  { id: '1', title: '160cm' },
  { id: '2', title: '164cm' },
  { id: '3', title: '168cm' },
  { id: '4', title: '172cm' },
  { id: '5', title: '176cm' },
  { id: '6', title: '180cm' },
]

export const WeightCollection = [
  { id: '1', title: '50kg' },
  { id: '2', title: '54kg' },
  { id: '3', title: '58kg' },
  { id: '4', title: '62kg' },
  { id: '5', title: '66kg' },
  { id: '6', title: '70kg' },
]

export const CastingTypeCollection = [
  { id: '1', title: 'Movies' },
  { id: '2', title: 'Television' },
  { id: '3', title: 'Commercial' },
  { id: '4', title: 'Newspaper' },
  { id: '5', title: 'Magazine' },
]

export function insertEmployee(data) {
  axios
    .post('https://smilingbackend.herokuapp.com/api/models/all', {
      firstName: data.firstName,
      secondName: data.secondName,
      email: data.email,
      gender: data.gender,
      professionId: ProfessionCollection[data.professionId].title,
      ShoeSizeId: ShoeSizeCollection[data.ShoeSizeId].title,
      BraSizeId: BraSizeCollection[data.BraSizeId].title,
      CastingTypeId: CastingTypeCollection[data.CastingTypeId].title,
      HairColorId: HairColorCollection[data.HairColorId].title,
      HairLengthId: HairLengthCollection[data.HairLengthId].title,
      HeightId: HeightCollection[data.HeightId].title,
      WaistSizeId: WaistSizeCollection[data.WaistSizeId].title,
      WeightId: WeightCollection[data.WeightId].title,
      birthDate: data.birthDate,
    })
    .then((res) => {
      // this.setState({
      ///   authToken: res.data.authToken,
      // })
      //setauthToken(res.data.authToken)
      //console.log('working')
    })

  //  let employees = getAllEmployees()
  // data['id'] = generateEmployeeId()
  // employees.push(data)
  // localStorage.setItem(KEYS.employees, JSON.stringify(employees))
}

export function generateEmployeeId() {
  if (localStorage.getItem(KEYS.employeeId) == null)
    localStorage.setItem(KEYS.employeeId, '0')
  var id = parseInt(localStorage.getItem(KEYS.employeeId))
  localStorage.setItem(KEYS.employeeId, (++id).toString())
  return id
}

export function getAllEmployees() {
  if (localStorage.getItem(KEYS.employees) == null)
    localStorage.setItem(KEYS.employees, JSON.stringify([]))
  return JSON.parse(localStorage.getItem(KEYS.employees))
}
